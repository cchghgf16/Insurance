<?php
include('conn.php');

?>
<!doctype html>

<html>

<head>

<meta charset="utf-8">

<meta name="viewport" content="initial-scale=1.0,user-scalable=no,maximum-scale=1,width=device-width">

<meta http-equiv="Cache-Control" content="no-transform" />

<meta http-equiv="Cache-Control" content="no-siteapp" />

<meta name="applicable-device" content="pc,mobile">

<meta name="author" content="order by">

<title>Home</title>

<meta name="keywords" content="" />
<link href="css/swiper.min.css" rel="stylesheet" type="text/css">

<link href="css/mian.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/iconfont.css">

</head>

<body>

<div class="topmenu" id="tophead">

  <div class="wrap">

    <div id="mobilemenu"></div>

    <div class="mask"></div>

    <div class="logo"><a href='javascript:0'><img src="images/logo.jpg"  width="70" height="70" style="margin-left:70px"></a></div>

    <div class="menu">

      <ul id="nav">

        <li class="closex"><i class="iconfont icon-guanbi"></i></li>

        <li class="mainlevel"><a  class='hover'href="index.php">Home</a></li>

        <li class="mainlevel"><a href='list.php'>List of works</a></li>
        <li class="mainlevel"><a href='liuyan.php'>New post</a></li>
         <li class="mainlevel"><a href='login.php' style="position: absolute;right:-500px">Login/Register</a></li>
        <div class="clear"></div>

      </ul>

    </div>

  

  </div>

</div>



<div class="main" >

  <div class="wrap">

    <div class="row">

      <div class="banner" style="width: 100%">

        <div class="swiper-container">

          <div class="swiper-wrapper"> <div class="swiper-slide" style="background-image:url(images/1-2003301I501459.gif)"><a href='javascript:0' title=""></div>

<div class="swiper-slide" style="background-image:url(images/1-2003301I444191.jpg)"><a href='javascript:0' title="">

           

         </div>
         <div class="swiper-slide" style="background-image:url(images/333.jpg)"><a href='javascript:0' title="">

           

         </div>

 </div>

          <div class="swiper-pagination"></div>

          <div class="swiper-button-prev"></div>

          <div class="swiper-button-next"></div>

        </div>

      </div>


             
       

          </div>

        </div>

      </div>

    </div>

  </div>

</div>



 </div>

  </div>

</div>


 </div>

  </div>

</div>

<div class="footer">

  <div class="wrap">

   

   

   
    <div class="copyright-footer">
      <center>
      <p> @ Copyright</p>
</center>
    </div>


 
	</div>

  </div>

</div>


<script type="text/javascript" src="js/jquery.min.js"></script> 

<script type="text/javascript" src="js/swiper.min.js"></script> 

<script type="text/javascript" src="js/slide.js"></script>

</body>

</html>