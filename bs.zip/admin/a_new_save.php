
<?php
include('conn.php');
mysqli_query($conn,"set names utf8");//设置数据库编码格式utf8
/* 检测连接是否成功 */
if (!$conn) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}
/* 检测是否生成MySQLi_STMT类 */
$stmt = mysqli_prepare($conn, "insert into admin (username,password,flag) VALUES (?, ?, ?)");
if ( !$stmt ) {
    die('mysqli error: '.mysqli_error($conn));
}
/* 获取POST提交数据 */
$name=$_POST['username'];
 $sex=$_POST['password'];
 $age=$_POST['flag'];



/* 参数绑定 */
mysqli_stmt_bind_param($stmt, 'sss', $name, $sex, $age);
/* 执行prepare语句 */
mysqli_stmt_execute($stmt);
/* 根据执行结果，跳转页面 */
if(mysqli_stmt_affected_rows($stmt)){
    echo "<script>alert('Success');</script>";
}else{
    echo "<script>alert('false');</script>";
}
echo "<script>location.href='a_list.php'</script>";
?>