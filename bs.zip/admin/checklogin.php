<?php
include('conn.php');
session_start();
$username=$_POST['username'];
$password=$_POST['password'];



	
$sql="select * from admin where username='$username' and password='$password'";
$rs=mysqli_query($conn,$sql);

if($row=mysqli_fetch_assoc($rs)){
	
	$t=date('Y-m-d H:i',time());
	$ids=$row['id'];
	$sql2="update  admin setlasttime='$t' where id ='$ids'";

	$r=mysqli_query($conn,$sql2);
	
	$_SESSION['username']=$row['username'];
	$_SESSION['name']=$row['name'];
	$_SESSION['userid']=$row['id'];
	$_SESSION['type']=$row['flag'];;
	$_SESSION['t']=$row['lasttime'];;
	header('Location:index.php');
}else{
	echo "<script>alert('账号密码错误');</script>";	
	echo "<script>location.href='login.php'</script>";
}

	


	