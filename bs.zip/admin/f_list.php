<?php
include('conn.php');
session_start();
?>
<nav>
    <div>
    <div>
        <a>Post list</a>
    </div>
    <div>
        <ul class="nav navbar-nav">
          <form method="get">
     	

     	<input type="text" name="cont" placeholder="Email" class="layui-input" style="width:30%;float: left">
     	<input type="submit" value="Search" ="" class="layui-btn">
     </form>    
           
<div>
	<div>
		
		<table class="layui-table layui-form">
			<thead>
			<tr>
			
			</tr>
				<tr>
					<th align="center" bgcolor="#FFFFFF" height="27">ID</th>
					<th align="center" bgcolor="#FFFFFF">Email</th>
					<th align="center" bgcolor="#FFFFFF">Phone</th>
					<th align="center" bgcolor="#FFFFFF">Content</th>
					
				
					
					
				
				
				</tr>
			</thead>
		<tbody>
			<?php
				$p=isset($_GET['p'])?$_GET['p']:1;
				
			    if(!empty($_GET['cont'])){
				$sql="select * from `in`  where  email '%{$_GET['cont']}%' order by id desc ";
			
			}else{
				$sql="select * from `in`   order by id desc ";
			}
				$rs=mysqli_query($conn,$sql);
				$tiao=mysqli_num_rows($rs);
				$ye=ceil($tiao/1);
				$n=($p-1)*1;
				 if(empty($_GET['cont'])){
			    	$sql2="select * from `in` order by id desc limit $n,1";
			    }else{
			    	$sql2="select * from `in` where  email '%{$_GET['cont']}%' order by id desc limit $n,1";
			    }
				$rs2=mysqli_query($conn,$sql2);
			
				
				$rs=mysqli_query($conn,$sql);

				while($row=mysqli_fetch_assoc($rs2)){
					
					echo '<tr>';
					echo '<td align="center" bgcolor="#FFFFFF">'.$row['id'].'</td>';
					echo '<td align="center" bgcolor="#FFFFFF">'.$row['email'].'</td>';
					echo '<td align="center" bgcolor="#FFFFFF">'.$row['phone'].'</td>';
					
					echo '<td align="center" bgcolor="#FFFFFF">'.$row['content'].'</td>';
					echo '</tr>';
				}
				?>
		<tbody>
		</table>
		<div class="layui-card-body ">
                            <div class="page">
                                <div>
<?php for($i=1;$i<=$ye;$i++):?>
	<?php if($p==$i){?>
		 <span class="current"><?php echo $i?></span>
	<?php }else{?>
                                
                                  <a class="num " href="<?php if(empty($id)){?>
				f_list?p=<?php echo $i?>
			<?php }else{?>
				f_list?id=<?php echo $id?>&p=<?php echo $i?>
			<?php }?>"><?php echo $i?></a>
		<?php }?>
                                 <?php endfor?>
                                </div>
                            </div>
                        </div>
			
			</div>
			</div>