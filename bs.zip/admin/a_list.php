<?php
include('conn.php');

?>
<nav>
    <div>
    <div>
        <a>Userlist</a>
    </div>
    <div>
        <ul class="nav navbar-nav">
          <form method="get">
     	

     	<input type="text" name="cont" class="layui-input" style="width:30%;float: left">
     	<input type="submit" value="search" class="layui-btn">
     </form>    
           
<div>
	<div>
		
		<table class="layui-table layui-form">
			<thead>
			<tr>
			
			</tr>
				<tr>
					<td align="center" bgcolor="#FFFFFF" height="27">ID</td>
					<td align="center" bgcolor="#FFFFFF">Username</td>
					<td align="center" bgcolor="#FFFFFF">Type</td>
					<td align="center" bgcolor="#FFFFFF">Status</td>
					<td align="center" bgcolor="#FFFFFF">Option</td>
				</tr>
			</thead>
		<tbody>
			<?php
			
				if(!empty($_GET['cont'])){
				$sql="select * from admin  where username like '%{$_GET['cont']}%' order by id desc ";
			
			}else{
				$sql="select * from admin   order by id desc ";
			}
				
				$rs=mysqli_query($conn,$sql);

				while($row=mysqli_fetch_assoc($rs)){
					echo '<tr>';
					echo '<td align="center" bgcolor="#FFFFFF">'.$row['id'].'</td>';
					echo '<td align="center" bgcolor="#FFFFFF">'.$row['username'].'</td>';
					switch ($row['flag']) {
						case '1':
							$fg='User';
							break;
						case '2':
							$fg='Admin';
							break;
						
						
					}
					if($row['status']==0){
						$stf='On';
					}else{
						$stf='Off';
					}


						
					
					echo '<td align="center" bgcolor="#FFFFFF">'.$fg.'</td>';
					echo '<td align="center" bgcolor="#FFFFFF">'.$stf.'</td>';
					echo '<td align="center" bgcolor="#FFFFFF">';
					echo '<a href="a_update.php?id='.$row['id'].'">Update</a> /';
					echo '<a href="a_delete.php?id='.$row['id'].'" onclick="return
					confirm(\'Delete?\')">Delete</a>';
					echo '</td>';
					echo '</tr>';
				}
				?>
		<tbody>
		</table>	
			</div>
			</div>