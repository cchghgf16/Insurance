<?php
include('conn.php');


$id=$_GET['id'];

if(!is_numeric($id)){
	alert('ID值不是一个数字','staff_list.php');exit;
}	
	
	$sql="delete from admin where id=$id";
	$r=mysqli_query($conn,$sql);
	
	if($r){
    echo "<script>alert('删除成功');</script>";
}else{
    echo "<script>alert('删除失败');</script>";
}
echo "<script>location.href='a_list.php'</script>";

