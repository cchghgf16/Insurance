<?php
include('conn.php');
$id=$_POST['id'];
$name=$_POST['username'];
$sex=$_POST['flag'];
$age=$_POST['password'];
$stf=$_POST['stf'];



$sql="update  admin set username='$name',flag='$sex',password='$age',status='$stf' where id ='$id'";


$r=mysqli_query($conn,$sql);

if($r){
    echo "<script>alert('Success');</script>";
}else{
    echo "<script>alert('false');</script>";
}
echo "<script>location.href='a_list.php'</script>";
?>
