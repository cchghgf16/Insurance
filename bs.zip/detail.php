<?php
include('conn.php');
$type=isset($_GET['t'])?$_GET['t']:'a';
$id=isset($_GET['id'])?$_GET['id']:'';
  if($type=='a'){
            $sql="select * from jxxx   where id={$id} ";
        }elseif($type=='b'){
          $sql="select * from jxzy  where id={$id}   ";
        }elseif($type=='c'){
          $sql="select * from zy where id={$id}";
        }
      
      
        
        $rs=mysqli_query($conn,$sql);

       $row=mysqli_fetch_assoc($rs);
?>
<!doctype html>

<html>

<head>

<meta charset="utf-8">

<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />

<meta http-equiv="Cache-Control" content="no-transform" />

<meta http-equiv="Cache-Control" content="no-siteapp" />

<meta name="applicable-device" content="pc,mobile">

<title>Detail</title>





<link href="css/swiper.min.css" rel="stylesheet" type="text/css">

<link href="css/mian.css" rel="stylesheet" type="text/css">

</head>

<body>

<div class="topmenu" id="tophead">

  <div class="wrap">

    <div id="mobilemenu"></div>

    <div class="mask"></div>

    <div class="logo"><a href='javascript:0'><img src="images/logo.jpg"  width="70" height="70" style="margin-left:70px"></a></div>

  <div class="menu">

     <ul id="nav">

        <li class="closex"><i class="iconfont icon-guanbi"></i></li>

        <li class="mainlevel"><a  class='hover'href="index.php">Index</a></li>

        

        <li class="mainlevel"><a href='list.php'>
List of works</a></li>
         

       
        <li class="mainlevel"><a href='login.php'>Login</a></li>
         <li class="mainlevel"><a href='liuyan.php'>Share</a></li>
        <div class="clear"></div>

      </ul>

    </div>

   

  </div>

</div>



<div class="subbody" >

  <div class="wrap" >

    <div class="row">

      <div class="left" style="width:100%">

        <div class="article-con">

          <div class="postion"><a href='javascript:0'>Index</a> > <a href='javascript:0'>Detail</a> </div>

          <div class="art-con">

            <h1><?php echo $row['title']?></h1>

            <div class="posts-default-info">

              <ul>

                <li class="post-author">

                  <div class="avatar"><img src="images/wordlm.jpg" height="96" width="96"></div>

                </li>

                <li class="ico-cat"><i class="iconfont icon-liebiao"></i> <a href='javascript:0'><?php echo $row['class']?></a> <a href="" onclick="alert('success')">Collection</a> </li>


               

              </ul>

            </div>

            <div class="art-txt"> <p>

	&nbsp;</p>

<p>

	</p>

<p>

	<?php echo $row['content']?></p>



 </div>

         
      

          </div>

        </div>

        <div class="article-con">

          <h3 class="subtitle"><span>Comment</span></h3>

          <ul class="sub-news">

            <li>
               <?php
      
       
          $sql="select * from comment where jid ={$id}   ";
        
     
      
        
        $rs=mysqli_query($conn,$sql);

        while($row=mysqli_fetch_assoc($rs)){
        ?>
              <div>
                <img src="images/36.jpg" height="36" width="36" style="float: left"><p style="position: relative;top:10px;left:5px">Member</p><div style="clear: both"></div>
              <a href='detail.php?t=<?php echo $type?>&id=<?php echo $row['id']?>' ><?php echo $row['content']?></a>
              <hr width="1000">
              </div>
              <br>
                <?php
        }
    ?>
            </li>


 
     <form method="post" action="docm.php">
        <input type="hidden" name="jid" value="<?php echo $id?>">
          <textarea name="content" style="width:80%;height:150px;margin-left:10%;border:1px solid rgb(200,200,200);padding:10px" placeholder="Please enter the message..."></textarea><br><br>
          <input type="submit" name="" style="margin-left:45%">
        </form>

          </ul>

        </div>

      </div>

     

      <div class="right">


 

 



</div>

 </div>

  </div>

</div>

<div class="footer">

  <div class="wrap">

   

    <div class="copyright-footer">

      <p>Copyright </a></p>

    </div>

   
  </div>

</div>


  <i class="iconfont icon-guanbi close_tip"></i> </div>

<script type="text/javascript" src="js/jquery.min.js"></script> 

<script type="text/javascript" src="js/swiper.min.js"></script> 

<script type="text/javascript" src="js/slide.js"></script> 

<script> window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"24"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>

</body>

</html>