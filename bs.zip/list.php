<?php
include('conn.php');
$type=isset($_GET['t'])?$_GET['t']:'a';

?>
<!doctype html>

<html>

<head>

<meta charset="utf-8">

<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />

<meta http-equiv="Cache-Control" content="no-transform" />

<meta http-equiv="Cache-Control" content="no-siteapp" />

<meta name="applicable-device" content="pc,mobile">

<title>list</title>

<meta name="keywords" content="" />

<meta name="description" content="" />

<link href="css/swiper.min.css" rel="stylesheet" type="text/css">

<link href="css/mian.css" rel="stylesheet" type="text/css">

</head>

<body>

<div class="topmenu" id="tophead">

  <div class="wrap">

    <div id="mobilemenu"></div>

    <div class="mask"></div>

     <div class="logo"><a href='javascript:0'><img src="images/logo.jpg"  width="70" height="70" style="margin-left:70px"></a></div>

  <div class="menu">

          <ul id="nav">

        <li class="closex"><i class="iconfont icon-guanbi"></i></li>

        <li class="mainlevel"><a  class='hover'href="index.php">Home</a></li>

        <li class="mainlevel"><a href='list.php'>List of works</a></li>
        <li class="mainlevel"><a href='liuyan.php'>New post</a></li>
         <li class="mainlevel"><a href='login.php' style="position: absolute;right:-500px">Login/Register</a></li>
        <div class="clear"></div>

      </ul>


    </div>

    

  </div>

</div>



<div class="subbody" style="margin-left:20px;min-height: 500px">
      <div class="top-news">

        <div class="top-news-box">

          <h2>List of Work</h2>

          <div class="top-img" style="margin-left:20px"><a href='javascript:0'><img src="images/615.jpg" alt="" width="370" height="180"></a> </div>



          <div class="top-box">

            <ul class="topnews">

           <?php
      
       
        
        $sql="select * from jxxx   order by id desc limit 3 ";
      
        
        $rs=mysqli_query($conn,$sql);

        while($row=mysqli_fetch_assoc($rs)){
        ?>
 <li><a href='detail.php?t=a&id=<?php echo $row['id']?>'><i class="iconfont icon-huoyan red"></i><?php echo $row['title']?></a></li>
        <?php
        }
        ?>  
            </ul>

          </div>

        </div>

      </div>
  <div class="wrap" style="min-height: 400px">

    <div class="row">

      <div class="left">

       

        <div class="article_box">
   <?php
      
       
        if($type=='a'){
            $sql="select * from jxxx   order by id desc ";
        }elseif($type=='b'){
          $sql="select * from jxzy   order by id desc ";
        }elseif($type=='c'){
          $sql="select * from zy   order by id desc ";
        }
      
      
        
        $rs=mysqli_query($conn,$sql);

        while($row=mysqli_fetch_assoc($rs)){
        ?>
 <div class="items">

            <div class="content-box">

              <div class="posts-gallery-img"> <a href="javascript:0"></a> </div>

              <div class="posts-gallery-content">

                <h2><a href="detail.php?t=<?php echo $type?>&id=<?php echo $row['id']?>" target="_blank"><?php echo $row['title']?></a></h2>

                <div class="posts-gallery-text"><?php echo $row['content']?></div>

                <div class="posts-default-info posts-gallery-info">

                  <ul>

                    <li class="ico-cat"><i class="iconfont icon-liebiao"></i> <a href="javascript:0"><?php echo $row['class']?></a></li>

                   

                  </ul>

                </div>

              </div>

            </div>

          </div>

        <?php
        }
        ?>
         

        <div class="pages">


        </div>

      </div>


      <div class="right">



 


</div>

 </div>

  </div>

</div>

<div class="footer">

  <div class="wrap">

   

    
   
    <div class="copyright-footer">
      <center>
      <p> @ Copyright</p>
</center>
    </div>



</div>



  <i class="iconfont icon-guanbi close_tip"></i> </div>

<script type="text/javascript" src="js/jquery.min.js"></script> 

<script type="text/javascript" src="js/swiper.min.js"></script> 

<script type="text/javascript" src="js/slide.js"></script>

</body>

</html>