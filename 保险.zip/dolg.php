<?php
include('conn.php');

$username=$_POST['username'];
$password=$_POST['password'];

$sql="select * from admin where username='$username' and password='$password'";
$rs=mysqli_query($conn,$sql);

if($row=mysqli_fetch_assoc($rs)){
	session_start();
	$_SESSION['username']=$row['username'];
	$_SESSION['userid']=$row['id'];
	$_SESSION['type']=$row['flag'];;
	header('Location:index.php');
}
else{
	echo'登陆失败,用户名或密码错误，请重试';exit;	
}
