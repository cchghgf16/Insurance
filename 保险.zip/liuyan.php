<?php
include('conn.php');


?>
<!doctype html>

<html>

<head>

<meta charset="utf-8">

<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />

<meta http-equiv="Cache-Control" content="no-transform" />

<meta http-equiv="Cache-Control" content="no-siteapp" />

<meta name="applicable-device" content="pc,mobile">

<title>Send</title>
<link href="css/swiper.min.css" rel="stylesheet" type="text/css">

<link href="css/mian.css" rel="stylesheet" type="text/css">

</head>

<body>

<div class="topmenu" id="tophead">

  <div class="wrap">

    <div id="mobilemenu"></div>

    <div class="mask"></div>

    <div class="logo"><a href='javascript:0'><img src="images/logo.jpg"  width="70" height="70" style="margin-left:70px"></a></div>

    <div class="menu">

    <ul id="nav">

        <li class="closex"><i class="iconfont icon-guanbi"></i></li>

        <li class="mainlevel"><a  class='hover'href="index.php">Home</a></li>

        <li class="mainlevel"><a href='list.php'>List of works</a></li>
        <li class="mainlevel"><a href='liuyan.php'>New post</a></li>
         <li class="mainlevel"><a href='login.php' style="position: absolute;right:-500px">Login/Register</a></li>
        <div class="clear"></div>

      </ul>


    </div>

  

  </div>

</div>



<div class="subbody" >

  <div class="wrap" >

    <div class="row">

      <div class="left" style="width:100%">

        <div class="article-con">

          <div class="postion"><a href='javascript:0'>Index</a> > <a href='javascript:0'>Submit</a> </div>

          <div class="art-con">

            <h1>Insurance </h1>

            <div class="posts-default-info">

              <ul>

                <li class="post-author">

                

                </li>

                


               

              </ul>

            </div>

            <div class="art-txt"> <p>

	&nbsp;</p>

<p>

	</p>

<p>
 <form method="post" action="doly.php">
        <input type="email" name="title" placeholder="Email" style="width:80%;height:30px;margin-left:10%;border:1px solid rgb(200,200,200);padding:10px"><br><br>
        <input type="" name="phone" placeholder="Phone" style="width:80%;height:30px;margin-left:10%;border:1px solid rgb(200,200,200);padding:10px"><br><br>
          <textarea name="content" style="width:80%;height:300px;margin-left:10%;border:1px solid rgb(200,200,200);padding:10px" placeholder="Please enter the message..."></textarea><br>   <br>
          <center> <input type="checkbox" name="">I have read and agree with the terms and conditions<br>
           <input type="submit" name="" style=";background: rgb(0,147,243);border: 1px solid rgb(200,200,200);padding:8px 30px;color: white;font-size: 16px" value="Submit"></center>
 
       
         

        </form>
	</p>
 </div>
          </div>

        </div>
      <div class="right">
</div>

 </div>

  </div>

</div>

<div class="footer">

  <div class="wrap">

   

    <div class="copyright-footer">

      <p> @ Copyright </a></p>

    </div>

   
  </div>

</div>

<div class="backtop" id="backtop"><i class="iconfont icon-xiangshang"></i></div>



</div>





<script type="text/javascript" src="js/jquery.min.js"></script> 

<script type="text/javascript" src="js/swiper.min.js"></script> 

<script type="text/javascript" src="js/slide.js"></script> 

<script> window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"24"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>

</body>

</html>