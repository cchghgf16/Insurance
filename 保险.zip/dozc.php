<?php
include('conn.php');

$username=$_POST['username'];
$password=$_POST['password'];
$flag=1;








$sql="select * from admin where username='$username'";
$rs=mysqli_query($conn,$sql);

if($row=mysqli_fetch_assoc($rs)){
	echo "<script>alert('该账户已注册');location.href='zc.php'</script>";die;
	
}
else{
	/* 检测是否生成MySQLi_STMT类 */
$stmt = mysqli_prepare($conn, "insert into admin (username,password,flag) VALUES (?,?,?)");
if ( !$stmt ) {
    die('mysqli error: '.mysqli_error($conn));
}
/* 获取POST提交数据 */



/* 参数绑定 */
mysqli_stmt_bind_param($stmt, 'sss', $username,$password,$flag);
/* 执行prepare语句 */
mysqli_stmt_execute($stmt);
/* 根据执行结果，跳转页面 */
if(mysqli_stmt_affected_rows($stmt)){
    echo "<script>alert('添加成功');</script>";
}else{
    echo "<script>alert('添加失败');</script>";
}
echo "<script>location.href='login.php'</script>";
}
